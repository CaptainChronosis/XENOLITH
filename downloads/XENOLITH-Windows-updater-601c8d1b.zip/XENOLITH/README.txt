XENOLITH // FM-1

Read INSTALL.md. Run Setup updater.bat once, then Update.bat.
Complete source and build instructions: https://github.com/CaptainChronosis/XENOLITH
