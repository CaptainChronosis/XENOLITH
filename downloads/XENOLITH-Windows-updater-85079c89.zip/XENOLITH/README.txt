XENOLITH // WINDOWS UPDATER

Extract this ZIP completely. Install Python 3.12 with its Windows py launcher.
Run Setup updater.bat once, then Update.bat. Read INSTALL.md before writing.

Firmware: 85079c89
Corresponding source and licences:
https://github.com/CaptainChronosis/XENOLITH

This updater does not require administrator access.
